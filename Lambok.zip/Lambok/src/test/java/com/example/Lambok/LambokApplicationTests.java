package com.example.Lambok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambokApplicationTests {

	@Test
	void contextLoads() {
	}

}
